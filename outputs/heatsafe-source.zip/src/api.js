const NOMINATIM_URL = 'https://nominatim.openstreetmap.org'
const ROUTER_URL = 'https://routing.openstreetmap.de/routed-foot/route/v1/driving'
const WEATHER_URL = 'https://api.open-meteo.com/v1/forecast'
const AIR_URL = 'https://air-quality-api.open-meteo.com/v1/air-quality'

const fetchJson = async (url, signal) => {
  const response = await fetch(url, { signal, headers: { Accept: 'application/json' } })
  if (!response.ok) throw new Error(`Live service returned ${response.status}`)
  return response.json()
}

export async function searchPlace(query, signal) {
  const params = new URLSearchParams({
    q: /maryland|baltimore/i.test(query) ? query : `${query}, Baltimore, Maryland`,
    format: 'jsonv2',
    limit: '1',
    addressdetails: '1',
    countrycodes: 'us',
  })
  const results = await fetchJson(`${NOMINATIM_URL}/search?${params}`, signal)
  if (!results.length) throw new Error(`We couldn't find “${query}”. Try a street address or landmark.`)
  return {
    lat: Number(results[0].lat),
    lng: Number(results[0].lon),
    label: results[0].display_name.split(',').slice(0, 3).join(','),
  }
}

export async function reversePlace(lat, lng, signal) {
  const params = new URLSearchParams({ lat, lon: lng, format: 'jsonv2', zoom: '18' })
  const place = await fetchJson(`${NOMINATIM_URL}/reverse?${params}`, signal)
  return place.name || place.display_name?.split(',')[0] || 'Current location'
}

const routeUrl = (points) => {
  const coordinates = points.map(({ lng, lat }) => `${lng},${lat}`).join(';')
  return `${ROUTER_URL}/${coordinates}?steps=true&geometries=geojson&overview=full`
}

const routeVariant = async (points, signal) => {
  const data = await fetchJson(routeUrl(points), signal)
  if (data.code !== 'Ok' || !data.routes?.[0]) throw new Error('No walkable route was found between these places.')
  return data.routes[0]
}

const makeWaypoint = (origin, destination, direction) => {
  const midLat = (origin.lat + destination.lat) / 2
  const midLng = (origin.lng + destination.lng) / 2
  const latDelta = destination.lat - origin.lat
  const lngDelta = destination.lng - origin.lng
  const length = Math.hypot(latDelta, lngDelta) || 1
  const offset = Math.min(0.0038, Math.max(0.0012, length * 0.2)) * direction
  return {
    lat: midLat - (lngDelta / length) * offset,
    lng: midLng + (latDelta / length) * offset,
  }
}

export async function getWalkingRoutes(origin, destination, signal) {
  const variants = [
    [origin, destination],
    [origin, makeWaypoint(origin, destination, 1), destination],
    [origin, makeWaypoint(origin, destination, -1), destination],
  ]
  const settled = await Promise.allSettled(variants.map((points) => routeVariant(points, signal)))
  const unique = settled
    .filter((result) => result.status === 'fulfilled')
    .map((result) => result.value)
    .filter((route, index, routes) => routes.findIndex((item) => Math.round(item.distance) === Math.round(route.distance)) === index)

  if (!unique.length) throw new Error('The free walking router is temporarily unavailable. Please try again.')
  while (unique.length < 3) unique.push({ ...unique[unique.length - 1] })

  const byDistance = [...unique].sort((a, b) => a.distance - b.distance)
  const definitions = [
    { id: 'coolest', name: 'Coolest route', color: '#087a78', exposure: 'Low', shade: 68, water: 2, source: unique[1] || unique[0] },
    { id: 'balanced', name: 'Balanced', color: '#e6a320', exposure: 'Medium', shade: 44, water: 1, source: unique[2] || unique[0] },
    { id: 'fastest', name: 'Fastest', color: '#f2665b', exposure: 'High', shade: 22, water: 0, source: byDistance[0] },
  ]

  return definitions.map(({ source, ...definition }) => ({
    ...definition,
    time: Math.max(1, Math.round(source.duration / 60)),
    distance: (source.distance / 1609.344).toFixed(1),
    geometry: source.geometry.coordinates.map(([lng, lat]) => [lat, lng]),
    steps: source.legs?.flatMap((leg) => leg.steps || []) || [],
  }))
}

export async function getConditions(lat, lng, signal) {
  const weatherParams = new URLSearchParams({
    latitude: lat,
    longitude: lng,
    current: 'temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code,is_day',
    temperature_unit: 'fahrenheit',
    wind_speed_unit: 'mph',
    timezone: 'auto',
  })
  const airParams = new URLSearchParams({ latitude: lat, longitude: lng, current: 'us_aqi', timezone: 'auto' })
  const [weather, air] = await Promise.all([
    fetchJson(`${WEATHER_URL}?${weatherParams}`, signal),
    fetchJson(`${AIR_URL}?${airParams}`, signal).catch(() => ({ current: {} })),
  ])
  return {
    temperature: Math.round(weather.current.temperature_2m),
    feelsLike: Math.round(weather.current.apparent_temperature),
    humidity: Math.round(weather.current.relative_humidity_2m),
    wind: Math.round(weather.current.wind_speed_10m),
    weatherCode: weather.current.weather_code,
    isDay: Boolean(weather.current.is_day),
    aqi: air.current?.us_aqi == null ? null : Math.round(air.current.us_aqi),
    updatedAt: new Date(weather.current.time),
  }
}
